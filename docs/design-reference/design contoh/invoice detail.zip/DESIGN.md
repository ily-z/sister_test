# Design System Document: The Precision Fleet Interface

## 1. Overview & Creative North Star: "The Architectural Lens"
This design system moves away from the cluttered, "data-dump" aesthetic common in ERPs. Our North Star is **The Architectural Lens**. Just as an observatory provides a clear, focused view of complex systems, this UI must feel expansive, intentional, and high-fidelity. 

We achieve this through **Atmospheric Depth**. By utilizing high-contrast typography against a "Precision White" canvas and replacing traditional borders with tonal shifts, we create an interface that feels like a physical piece of modern architecture—stable, expensive, and effortlessly organized. We break the "template" look by using generous white space and asymmetrical content clusters to lead the eye to critical car rental metrics.

---

## 2. Colors: Tonal Architecture
The palette is rooted in a "cool-neutral" foundation, punctuated by high-performance accents.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define major UI sections. Boundaries must be defined by background shifts. Use `surface_container_low` (#f2f4f6) for sidebars or secondary panels to contrast against the `surface` (#f7f9fb) background.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested physical layers. 
- **Base Level:** `surface` (#f7f9fb)
- **Structural Sections:** `surface_container` (#eceef0)
- **Interactive Cards:** `surface_container_lowest` (#ffffff) 

### The Glass & Gradient Rule
To add "soul" to the ERP, use **Glassmorphism** for floating overlays (e.g., Modals or Filter Drawers). 
- Use `primary` (#0058be) at 80% opacity with a `24px` backdrop blur.
- **Signature Gradient:** For primary CTAs (e.g., "Confirm Booking"), apply a subtle linear gradient from `primary` (#0058be) to `primary_container` (#2170e4) at a 135-degree angle. This adds a tactile, premium weight that flat color lacks.

---

## 3. Typography: Editorial Authority
We use **Inter** not just for legibility, but as an editorial tool. High contrast in scale is mandatory to create a clear information hierarchy in a data-heavy ERP.

| Level | Token | Size | Weight | Role |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-md` | 2.75rem | 700 | Hero metrics (e.g., Total Revenue) |
| **Headline** | `headline-sm` | 1.5rem | 600 | Page titles and primary section headers |
| **Title** | `title-md` | 1.125rem | 600 | Card titles and vehicle names |
| **Body** | `body-md` | 0.875rem | 400 | Standard data entry and descriptions |
| **Label** | `label-sm` | 0.6875rem | 700 | Uppercase; metadata (e.g., VIN, License Plate) |

**Editorial Note:** Use `on_surface_variant` (#424754) for labels to create a sophisticated "muted" contrast against the `on_surface` (#191c1e) data points.

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows and borders are "visual noise." We utilize **Tonal Layering** to define importance.

*   **The Layering Principle:** To lift an element, change its color, not its border. Place a `surface_container_lowest` (#ffffff) card on a `surface_container_low` (#f2f4f6) background. The change in hex code provides all the separation the eye needs.
*   **Ambient Shadows:** For "Floating" elements like dropdowns, use a `20px` blur with 6% opacity. The shadow color must be tinted with the surface color (e.g., a faint Slate Blue tint) to prevent the "dirty grey" look.
*   **The Ghost Border:** If a divider is mandatory for accessibility (e.g., in a high-density table), use `outline_variant` at **15% opacity**. Never use 100% opacity.
*   **Corner Radii:** 
    *   `md` (0.375rem) for interactive inputs.
    *   `xl` (0.75rem) for primary cards and containers.
    *   `full` (9999px) for status badges (e.g., "Available," "In Maintenance").

---

## 5. Components

### Buttons & CTAs
*   **Primary:** Gradient of `primary` to `primary_container`. White text. Roundedness: `md`.
*   **Secondary:** `surface_container_high` background with `on_surface` text. No border.
*   **Tertiary:** Ghost style; text-only using `primary` color.

### Data Cards (The Rental Unit)
**Forbid the use of divider lines.** Separate the vehicle image, the rental status, and the price using vertical white space (1.5rem / 24px). Use a `surface_container_lowest` background to make the card "pop" from the light grey page background.

### Input Fields
*   **Resting:** `surface_container_lowest` background with a `Ghost Border` (15% `outline_variant`).
*   **Focus:** `2px` solid `primary` border. No "glow," but a subtle `surface_tint` at 5% opacity background fill.

### Status Chips
*   **"Available":** `secondary_container` (#86f2e4) background with `on_secondary_container` (#006f66) text. 
*   **"Reserved":** `tertiary_container` background with `on_tertiary_container` text.

### Fleet Specialized Components
*   **Timeline Tracker:** Use a horizontal "Stepped" progress bar using `primary` for completed legs and `surface_container_highest` for upcoming legs. Avoid thin lines; use `8px` thick rounded bars for a "premium-physical" feel.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts for dashboards. A large "Primary Metric" card next to two smaller "Status" cards creates a more bespoke, editorial feel than three equal boxes.
*   **Do** prioritize "Breathing Room." If a screen feels cramped, increase the padding to `2rem` (32px) rather than adding a border.
*   **Do** use `backdrop-blur` (12px-20px) on navigation sidebars to allow the vehicle brand colors to peak through subtly.

### Don't
*   **Don't** use pure black (#000000) for text. Always use `on_surface` (#191c1e) to maintain the "Slate" professional tone.
*   **Don't** use 1px solid lines to separate list items. Use a 4px gap and a slight background hover state change instead.
*   **Don't** use "Glow" effects or heavy drop shadows. If it doesn't look like it's made of matte paper or frosted glass, it doesn't belong in this system.